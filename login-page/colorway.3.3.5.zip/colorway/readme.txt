To Install Colorway Theme, Put the "colorwaytheme" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

The Theme installs with the basic layout in place. You can configure the Home Page using the Themes Options Panel.

If you want to build a blog, use the Template Type as "Blog Page" from the Page Attributes Section within the Add new Page section. The blog would come up in the page you created.

The process is similar for creating the Contact us page and the gallery page. In the gallery page you need to upload the images using the upload image buttons and just have to save the changes. Nothing is needed to be appeared in the page as you hit publish, a nice gallery would come up. 

If you have any questions that are beyond the scope of this help file, You can Mail Us at enquiry@inkthemes.com

Theme Image Link are:-

https://pixabay.com/en/balance-inspiration-motivation-life-865079/
https://pixabay.com/en/notebooks-cafe-blog-mobile-569121/ 
http://pixabay.com/en/macbook-notebook-home-office-336704/
http://pixabay.com/en/office-meeting-business-partners-336368/
http://pixabay.com/en/home-office-workstation-office-336373/
http://pixabay.com/en/coffee-cup-counter-bell-drink-423198/

License info for all js:

* MIT License for jquery.tipsy.js
* MIT and GPL licenses for superfish.js

1. slitslider.js
/**
* jquery.slitslider.js v1.1.0
* http://www.codrops.com
*
* Licensed under the MIT license.
* http://www.opensource.org/licenses/mit-license.php
* 
* Copyright 2012, Codrops
* http://www.codrops.com
*/
 
2. jquery.ba-cond.min.js
* cond - v0.1 - 6/10/2009
* http://benalman.com/projects/jquery-cond-plugin/
* 
* Copyright (c) 2009 "Cowboy" Ben Alman
* Licensed under the MIT license
* http://benalman.com/about/license/
* 
* Based on suggestions and sample code by Stephen Band and DBJDBJ in the
* jquery-dev Google group: http://bit.ly/jqba1

3. Animate.css 
Animate.css - http://daneden.me/animate
Licensed under the MIT license


4. jquery.meanmenu.2.0.js
* jQuery meanMenu v2.0.8
* @Copyright (C) 2012-2014 Chris Wharton @ MeanThemes (https://github.com/meanthemes/meanMenu)

* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.

5. superfish.js
* Superfish v1.4.8 - jQuery menu widget
* Copyright (c) 2008 Joel Birch
*
* 	Dual licensed under the MIT and GPL licenses:
* 	http://www.opensource.org/licenses/mit-license.php
* 	http://www.gnu.org/licenses/gpl.html

6. 960_24_col_responsive.css
	960 Grid System Modified for
	Responsive layout 960 Grid 
	System ~ Core CSS.
	Learn more ~ http://960.gs/    
	Author: InkThemes
	Licensed under GPL and MIT.
	
7.  jquery.flexslider.js
	 * jQuery FlexSlider v2.5.0
	 * Copyright 2012 WooThemes
	 * Contributing Author: Tyler Smith